"""
Utility functions for NGOInfo-Copilot
""" 